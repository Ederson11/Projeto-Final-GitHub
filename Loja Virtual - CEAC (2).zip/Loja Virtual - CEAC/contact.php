<?php
session_start();

// Conectar ao banco de dados (substitua com suas credenciais)
$conn = new mysqli("localhost", "root", "", "livraria_online");

// Verificar a conexão
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Verificar se o usuário está logado como administrador
if (!isset($_SESSION['admin']) || $_SESSION['admin'] !== true) {
    header("Location: login.php"); // Redireciona para a página de login se não estiver logado como administrador
    exit();
}

// Função para obter todas as mensagens de contato
function getContactMessages($conn) {
    $messages = array();
    $result = $conn->query("SELECT * FROM contact_messages");
    while ($row = $result->fetch_assoc()) {
        $messages[] = $row;
    }
    return $messages;
}

// Adicionar mensagem de contato ao banco de dados
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $message = $_POST['message'];

    $sql = "INSERT INTO contact_messages (name, email, message) VALUES ('$name', '$email', '$message')";
    if ($conn->query($sql) === TRUE) {
        echo "Message added successfully!";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Contact</title>
    <style>
        body {
    font-family: Arial, sans-serif;
    background-color: #f4f4f4;
    margin: 0;
    padding: 10px;
}

h1, h2 {
    color: #333;
}

nav {
    background-color: #333;
    color: #fff;
    padding: 10px;
}

nav ul {
    list-style: none;
    padding: 0;
    margin: 0;
}

nav ul li {
    display: inline;
    margin-right: 10px;
}

a {
    color: #fff;
    text-decoration: none;
}

a:hover {
    text-decoration: underline;
}

h2 {
    margin-top: 20px;
}

table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 10px;
}

table, th, td {
    border: 1px solid #ddd;
}

th, td {
    padding: 10px;
    text-align: left;
}

th {
    background-color: #333;
    color: #fff;
}

form {
    width: 50%;
    margin: 20px auto;
    background-color: #fff;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

label {
    display: block;
    margin-bottom: 5px;
}

input, textarea {
    width: 100%;
    padding: 8px;
    margin-bottom: 10px;
    box-sizing: border-box;
}

button {
    background-color: #333;
    color: #fff;
    padding: 8px 12px;
    border: none;
    cursor: pointer;
}

button:hover {
    background-color: #555;
}

/* Ajustes para telas menores */
@media screen and (max-width: 600px) {
    form {
        width: 80%; /* Reduz a largura do formulário para telas menores */
    }
}

    </style>
</head>
<body>

<h1>Bem Vindo(a), Administrador(a)!</h1>

<nav>
    <ul>
        <li><a target="_blank" href="category.php">Categoria</a></li>
        <li><a target="_blank" href="books.php">Livros</a></li>
        <li><a target="_blank" href="contact.php">Contato</a></li>
        <li><a target="_blank" href="logout.php">Sair</a></li>
    </ul>
</nav>

<h2>Contato Mensagens</h2>
<table border="1">
    <thead>
        <tr>
            <th>Nome</th>
            <th>E-mail</th>
            <th>Mensagem</th>
        </tr>
    </thead>
    <tbody>
        <?php
        $messages = getContactMessages($conn);
        foreach ($messages as $message) {
            echo "<tr>
                    <td>{$message['name']}</td>
                    <td>{$message['email']}</td>
                    <td>{$message['message']}</td>
                  </tr>";
        }
        ?>
    </tbody>
</table>

<h2>Adicionar Nova Mensagem</h2>
<form action="contact.php" method="post">
    <label for="name">Nome</label>
    <input type="text" id="name" name="name" placeholder="Seu nome Completo" required>

    <label for="email">E-mail</label>
    <input type="email" id="email" name="email" placeholder="Seu Melhor E-Mail" required>

    <label for="message">Mensagem</label>
    <textarea id="message" name="message" placeholder="Digite a Mensagem que Desejas" required></textarea>

    <button type="submit">Adicionar Mensagem</button>
</form>

</body>
</html>
