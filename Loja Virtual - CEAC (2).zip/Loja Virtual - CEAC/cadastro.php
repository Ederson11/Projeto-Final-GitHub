<?php
error_reporting(0);
   // Formulário de Processamento de Valores! //   
   if(isset($_POST['submit']))
   {

/*
   if(isset($_POST['submit'])){
      print_r($_POST['Nome']);
      print_r('<br />');
      print_r($_POST['Email']);
      print_r('<br />');
      print_r($_POST['Senha']);
   }
*/
   include_once('Connect/conexão.php');

   $username = $_POST['nome'];
   $email    = $_POST['email'];
   $password = $_POST['senha'];

   $result = mysqli_query($conexao, "INSERT INTO users(username, email, password) 
   VALUES ('$username', '$email', '$password')");
}

/*
$username = $_POST['name'];
$password = password_hash($_POST['password'], PASSWORD_DEFAULT);
$role = 'user';

$sql = "INSERT INTO users (name, password, role) VALUES ('$name', '$password', '$role')";

if ($conn->query($sql) === TRUE) {
    echo "Usuário cadastrado com sucesso!";
} else {
    echo "Erro ao cadastrar usuário: " . $conn->error;
}

$conn->close(); */
?> 
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8" />
    <meta http-equiv="Content-type" content="text/html;" />
    <meta name="author" content="Éderson P.S" />
    <meta http-equiv="X-UA-Compatible" content="IE-edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0" />
    <title>Cadastro Loja Technology Livraturas!</title>
    <link rel="stylesheet" href="css/Form.css">
    <style type="text/css">
      body{
         color: black;
         font-family: sans-Serif;
      }
      section{
        border-radius: 10px;
      }
    </style>
</head>
<body>
    <section>
    <form action="cadastro.php" method="post"><label><center><h1>Cadastro</h1></center></label>
        <label><h3>Nome</h3></label>
        <input type="text" placeholder="Digite Seu Nome Completo" name="nome" required />
        <label><h3>Email</h3></label>
        <input type="text" placeholder="Digite Sua Senha" name="email" required /><br /><br />
        <label><h3>Senha</h3></label>
        <input type="password" placeholder="Digite Sua Senha" name="senha" required /><br /><br />
        <button type="submit" name="submit">CADASTRAR</button> <!-- Se Parar de Cadastrar Mudar Este Botão Para Input! -->
    </form>
    </section>
</body>
</html>