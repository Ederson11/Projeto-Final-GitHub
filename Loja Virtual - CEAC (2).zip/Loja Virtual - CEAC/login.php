<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8" />
    <meta http-equiv="Content-type" content="text/html;" />
    <meta name="author" content="Éderson P.S" />
    <meta http-equiv="X-UA-Compatible" content="IE-edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0" />
    <title>Login Loja Technology Livraturas!</title>
    <link rel="stylesheet" href="css/Form.css">
    <style type="text/css"> /*
      body{
         color: black;
         font-family: sans-Serif;
      } */
      section{
        border-radius: 15px;
      } 

      body {
    font-family: Arial, sans-serif;
    background-color: #f4f4f4;
    margin: 0;
    padding: 0;
}

.container {
    width: 300px;
    margin: 100px auto;
    background-color: #fff;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

h2 {
    color: #333;
    text-align: center;
}

form {
    margin-top: 20px;
}

label {
    display: block;
    margin-bottom: 5px;
}

input {
    width: 100%;
    padding: 8px;
    margin-bottom: 10px;
    box-sizing: border-box;
}

button {
    background-color: #333;
    color: #fff;
    padding: 8px 12px;
    border: none;
    cursor: pointer;
    width: 100%;
}

button:hover {
    background-color: #555;
}

.error-message {
    color: red;
    margin-bottom: 10px;
    text-align: center;
}

/* Ajustes para telas menores */
@media screen and (max-width: 600px) {
    .container {
        width: 80%; /* Reduz a largura do contêiner para telas menores */
    }
}

    </style>
</head>
<body>
    <section>
    <form action="script_login.php" method="POST"><label><center><h1>Login</h1></center></label>
        <label><h3>Nome</h3></label>
        <input type="text" placeholder="Seu Nome Completo" name="nome" required /><br />
        <label><h3>E-Mail</h3></label>
        <input type="text" placeholder="Digite Seu Melhor E-Mail" name="email" required /><br />
        <label><h3>Senha</h3></label>
        <input type="password" placeholder="Digite Sua Senha" name="senha" required /><br /><br />
        <input type="submit" target="_blank" name="submit" value="ACESSAR"></input>
    </form>
    </section>
</body>
</html>