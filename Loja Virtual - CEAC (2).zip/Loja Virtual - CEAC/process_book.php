<?php
session_start();

// Verifica se o usuário está logado como administrador
if (!isset($_SESSION['admin']) || $_SESSION['admin'] !== true) {
    header("Location: login.php");
    exit();
}

// Conectar ao banco de dados (substitua com suas credenciais)
$conn = new mysqli("localhost", "root", "", "livraria_online");

// Verificar a conexão
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Obter dados do formulário
$title = $_POST['title'];
$description = $_POST['description'];
$category_id = $_POST['category_id'];

// Inserir dados na tabela de livros
$sql = "INSERT INTO books (title, description, category_id) VALUES ('$title', '$description', '$category_id')";

if ($conn->query($sql) === TRUE) {
    echo "Book added successfully!";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

// Fechar a conexão
$conn->close();
?>
