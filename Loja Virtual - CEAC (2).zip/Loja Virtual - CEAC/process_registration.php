<?php
// Conectar ao banco de dados (substitua com suas credenciais)
 $conn = new mysqli("localhost", "root", "", "livraria_online");

// Verificar a conexão
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

// Obter dados do formulário
$username = $_POST['username']; /* 
$password = $_POST['password']; */  
$password = password_hash($_POST['password'], PASSWORD_BCRYPT); // Armazenar a senha com hash 

// Inserir dados no banco de dados
$sql = "INSERT INTO administradores (username, password) VALUES ('$username', '$password')";

if ($conn->query($sql) === TRUE) {
    echo "Registration successful!";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

// Fechar a conexão
$conn->close();
?>
