<!--
<php
session_start();

// Verifica se o botão Adicionar ao carrinho foi clicado
if (isset($_POST['addcarrinho'])) {
    $id_produto = $_POST['id_produto'];
    $valor = $_POST['valor'];

    // Cria um array de produtos no carrinho se ainda não existir
    if (!isset($_SESSION['carrinho'])) {
        $_SESSION['carrinho'] = array();
    }

    // Adiciona o produto ao carrinho
    $_SESSION['carrinho'][] = array(
        'id_produto' => $id_produto,
        'valor' => $valor
    );

    // Redireciona de volta para a página de produtos
    header("Location: catalogo.php");
    exit();
}

// Outras verificações e manipulações do carrinho podem ser adicionadas aqui

?>
-->
<!--
<php
session_start();

// Função para adicionar um livro ao carrinho
function adicionarAoCarrinho($id_produto, $titulo, $preco) {
    // Inicializa o carrinho se não existir
    if (!isset($_SESSION['carrinho'])) {
        $_SESSION['carrinho'] = array();
    }

    // Verifica se o produto já está no carrinho
    $produtoExistente = false;
    foreach ($_SESSION['carrinho'] as &$item) {
        if ($item['id_produto'] == $id_produto) {
            $item['quantidade']++;
            $produtoExistente = true;
            break;
        }
    }

    // Se o produto não estiver no carrinho, adiciona um novo item
    if (!$produtoExistente) {
        $novoItem = array(
            'id_produto' => $id_produto,
            'titulo' => $titulo,
            'preco' => $preco,
            'quantidade' => 1
        );
        $_SESSION['carrinho'][] = $novoItem;
    }
}

// Verifica se o botão "addcarrinho" foi acionado
if (isset($_POST['addcarrinho'])) {
    // Simule os dados do livro (você pode obter essas informações do banco de dados)
    $id_produto = $_POST['id_produto']; // Adicione aqui o ID do produto
    $titulo = $_POST['titulo']; // Adicione aqui o título do produto
    $preco = $_POST['preco']; // Adicione aqui o preço do produto

    // Adiciona o livro ao carrinho
    adicionarAoCarrinho($id_produto, $titulo, $preco);
}

// Exibe o número de itens no carrinho
$numItensCarrinho = isset($_SESSION['carrinho']) ? count($_SESSION['carrinho']) : 0;

// Exemplo de como exibir o número de itens no carrinho
echo '<div class="cart"><i class="fa fa-shopping-cart"></i><p>' . $numItensCarrinho . '</p></div>';
?>


<php
session_start();

// Função para adicionar um produto ao carrinho
function adicionarAoCarrinho($id_produto, $titulo, $preco) {
    // Inicializa o carrinho se não existir
    if (!isset($_SESSION['carrinho'])) {
        $_SESSION['carrinho'] = array();
    }

    // Verifica se o produto já está no carrinho
    $produtoExistente = false;
    foreach ($_SESSION['carrinho'] as &$item) {
        if ($item['id_produto'] == $id_produto) {
            $item['quantidade']++;
            $produtoExistente = true;
            break;
        }
    }

    // Se o produto não estiver no carrinho, adiciona um novo item
    if (!$produtoExistente) {
        $novoItem = array(
            'id_produto' => $id_produto,
            'titulo' => $titulo,
            'preco' => $preco,
            'quantidade' => 1
        );
        $_SESSION['carrinho'][] = $novoItem;
    }
}

// Lista de produtos (pode vir do banco de dados)
$produtos = array(
    array('id' => 1, 'titulo' => 'Produto 1', 'preco' => 19.99),
    array('id' => 2, 'titulo' => 'Produto 2', 'preco' => 29.99),
    array('id' => 3, 'titulo' => 'Produto 3', 'preco' => 39.99),
);

// Verifica se o botão "addcarrinho" foi acionado
if (isset($_POST['addcarrinho'])) {
    $id_produto = $_POST['id_produto'];
    $produto = buscarProdutoPorId($id_produto, $produtos);

    if ($produto) {
        adicionarAoCarrinho($produto['id'], $produto['titulo'], $produto['preco']);
    }
}

// Função para buscar um produto pelo ID
function buscarProdutoPorId($id, $produtos) {
    foreach ($produtos as $produto) {
        if ($produto['id'] == $id) {
            return $produto;
        }
    }
    return null;
}

// Exibe o número de itens no carrinho
$numItensCarrinho = isset($_SESSION['carrinho']) ? count($_SESSION['carrinho']) : 0;
?>
-->

<?php
session_start();

// Verifica se há itens no carrinho
if(isset($_SESSION['carrinho']) && count($_SESSION['carrinho']) > 0) {
    echo "<h2>Itens no Carrinho</h2>";
    echo "<ul>";
    $total = 0;
    foreach($_SESSION['carrinho'] as $produto_id => $produto) {
        echo "<li>{$produto['nome']} - Quantidade: {$produto['quantidade']} - Preço: R$ {$produto['preco']}</li>";
        $total += $produto['quantidade'] * $produto['preco'];
    }
    echo "</ul>";
    echo "<p>Total: R$ $total</p>";
} else {
    echo "<p>Carrinho vazio.</p>";
}

echo "<a href='index.html'>Continuar Comprando</a>";
?>
