<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Book</title>
</head>
<body>

<h1>Add Book</h1>

<form action="process_book.php" method="post">
    <label for="title">Title:</label>
    <input type="text" id="title" name="title" required>

    <label for="description">Description:</label>
    <textarea id="description" name="description" required></textarea>

    <label for="category_id">Category ID:</label>
    <input type="number" id="category_id" name="category_id" required>

    <button type="submit">Add Book</button>
</form>

</body>
</html>
