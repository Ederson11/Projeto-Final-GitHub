<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro Admin</title>
    <style>
        body {
    font-family: Arial, sans-serif;
    background-color: #f4f4f4;
    margin: 0;
    padding: 10px;
}

.container {
    width: 300px;
    margin: 100px auto;
    background-color: #fff;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

h2 {
    color: #333;
    text-align: center;
}

form {
    margin-top: 20px;
}

label {
    display: block;
    margin-bottom: 5px;
}

input {
    width: 550px;
    padding: 8px;
    margin-bottom: 10px;
    box-sizing: border-box;
}

button {
    background-color: #333;
    color: #fff;
    padding: 8px 12px;
    border: none;
    cursor: pointer;
    width: 550px;
}

button:hover {
    background-color: #555;
}

.error-message {
    color: red;
    margin-bottom: 10px;
    text-align: center;
}

/* Ajustes para telas menores */
@media screen and (max-width: 600px) {
    .container {
        width: 80%; /* Reduz a largura do contêiner para telas menores */
    }
}


/* Adicione essas regras CSS para centralizar e alinhar os campos verticalmente */
form {
    margin-bottom: 20px;
    text-align: center; /* Alinha o conteúdo do formulário ao centro */
}

label {
    display: flex;
    margin-bottom: 5px;
    padding-left: 483px;
}

input, textarea, select {
    width: 550px; /* Faz os campos ocuparem 100% da largura do contêiner pai */
    padding: 8px;
    box-sizing: border-box; /* Garante que o preenchimento não altere a largura total do elemento */
    margin-bottom: 10px;
}

button {
    margin-top: 10px; /* Adiciona um espaçamento superior ao botão */
}

/* Ajustes para telas menores */
@media screen and (max-width: 600px) {
    form {
        width: 80%; /* Reduz a largura do formulário para telas menores */
        margin: 0 auto; /* Centraliza o formulário na tela */
    }
}

    </style>
</head>
<body>
<form action="process_registration.php" method="post"><label><center><h1>Cadastro Admin</h1></center></label>
    <label for="username">Nome</label>
    <input type="text" id="username" name="username" placeholder="Digite Seu Nome Completo" required />
    <label for="password">Senha</label>
    <input type="password" id="password" name="password" placeholder="Digite Uma Senha Confiável" required /><br />
    <button type="submit">Cadastrar</button>
</form>

</body>
</html>
