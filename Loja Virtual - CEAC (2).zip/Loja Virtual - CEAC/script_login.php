<?php
echo "<script>alert('Faça o Login, ou se For Novo(a) se Cadastre Para Ver e Adquirir os Nosso Produtos da Technology Livraturas!');</script>";
error_reporting(0);

// print_r($_REQUEST);
if(isset($_POST['submit']) && !empty($_POST['nome']) && !empty($_POST['email']) && !empty($_POST['senha']))
{
   // Acessa
   include_once('Connect/conexão.php');
   $username = $_POST['nome'];
   $email    = $_POST['email'];
   $password = $_POST['senha'];

  // print_r('Nome: ' . $username);
  // print_r('<br />');
  // print_r('Email: ' . $email);
  // print_r('<br />');
  // print_r('Senha: ' . $password);

  $sql = "SELECT * FROM users WHERE username = '$username' and email = '$email' and password = '$password'";

  $result = $conexao->query($sql);

  // print_r($sql);
  // print_r($result);

  if(mysqli_num_rows($result) < 1)
  {
      header('Location: login.php');
  }
  else
  {
      header('Location: index1.html');
  }
}
else
{ 
   // Não Acessa
 header('Location: login.php');
}

?>