<?php
session_start();

// Conectar ao banco de dados (substitua com suas credenciais)
$conn = new mysqli("localhost", "root", "", "livraria_online");

// Verificar a conexão
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Verificar se o usuário está logado como administrador
if (!isset($_SESSION['admin']) || $_SESSION['admin'] !== true) {
    header("Location: login.php"); // Redireciona para a página de login se não estiver logado como administrador
    exit();
}

// Função para obter todos os livros
function getLivros($conn) {
    $livros = array();
    $result = $conn->query("SELECT * FROM livros");
    while ($row = $result->fetch_assoc()) {
        $livros[] = $row;
    }
    return $livros;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Books</title>
    <style>
        body {
    font-family: Arial, sans-serif;
    background-color: #f4f4f4;
    margin: 0;
    padding: 10px;
}

h1, h2 {
    color: #333;
}

nav {
    background-color: #333;
    color: #fff;
    padding: 10px;
}

nav ul {
    list-style: none;
    padding: 0;
    margin: 0;
}

nav ul li {
    display: inline;
    margin-right: 10px;
}

a {
    color: #fff;
    text-decoration: none;
}

a:hover {
    text-decoration: underline;
}

h2 {
    margin-top: 20px;
}

table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 10px;
}

table, th, td {
    border: 1px solid #ddd;
}

th, td {
    padding: 10px;
    text-align: left;
}

th {
    background-color: #333;
    color: #fff;
}

/* Ajustes para telas menores */
@media screen and (max-width: 600px) {
    table {
        width: 80%; /* Reduz a largura da tabela para telas menores */
        margin: 0 auto; /* Centraliza a tabela na tela */
    }
}

    </style>
</head>
<body>

<h1>Bem Vindo(a), Administrador(a)!</h1>

<nav>
    <ul>
        <li><a target="_blank" href="category.php">Categoria</a></li>
        <li><a target="_blank" href="books.php">Livros</a></li>
        <li><a target="_blank" href="contact.php">Contato</a></li>
        <li><a target="_blank" href="logout.php">Sair</a></li>
    </ul>
</nav>

<h2>Livros</h2>
<table border="1">
    <thead>
        <tr>
            <th>Titlo</th>
            <th>Descrição</th>
            <th>Autor</th>
        </tr>
    </thead>
    <tbody>
        <?php
        $livros = getLivros($conn);
        foreach ($livros as $livro) {
            echo "<tr>
                    <td>{$livro['title']}</td>
                    <td>{$livro['description']}</td>
                    <td>{$livro['author']}</td>
                  </tr>";
        }
        ?>
    </tbody>
</table>

</body>
</html>
