<!--
session_start();

// Verifica se o usuário está logado como administrador
if (!isset($_SESSION['admin']) || $_SESSION['admin'] !== true) {
    header("Location: login.php"); // Redireciona para a página de login se não estiver logado como administrador
    exit();
}

// Simula o carregamento de categorias, subcategorias e livros (substitua isso com dados do banco de dados)
$categories = ['Category 1', 'Category 2', 'Category 3'];
$subcategories = ['Subcategory 1', 'Subcategory 2', 'Subcategory 3'];
$books = ['Book 1', 'Book 2', 'Book 3'];

?>
-->

<?php
session_start();

// Conectar ao banco de dados (substitua com suas credenciais)
$conn = new mysqli("localhost", "root", "", "livraria_online");

// Verificar a conexão
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Verificar se o usuário está logado como administrador
if (!isset($_SESSION['admin']) || $_SESSION['admin'] !== true) {
    header("Location: login.php"); // Redireciona para a página de login se não estiver logado como administrador
    exit();
}

// Função para obter todas as categorias
function getCategories($conn) {
    $categories = array();
    $result = $conn->query("SELECT * FROM categories");
    while ($row = $result->fetch_assoc()) {
        $categories[] = $row;
    }
    return $categories;
}

// Adicionar livro ao banco de dados
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $title = $_POST['title'];
    $description = $_POST['description'];
    $author = $_POST['author'];


    $sql = "INSERT INTO livros (title, description, author) VALUES ('$title', '$description', '$author')";
    if ($conn->query($sql) === TRUE) {
        echo "Book added successfully!";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
} 
?> 

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="css/.css">
    <style>
body {
    font-family: Arial, sans-serif;
    background-color: #f4f4f4;
    margin: 0;
    padding: 10px;
}

h1, h2 {
    color: #333;
}

nav {
    background-color: #333;
    color: #fff;
    padding: 10px;
}

nav ul {
    list-style: none;
    padding: 0;
    margin: 0;
}

nav ul li {
    display: inline;
    margin-right: 10px;
}

a {
    color: #fff;
    text-decoration: none;
}

a:hover {
    text-decoration: underline;
}

h2 {
    margin-top: 20px;
}

form {
    margin-bottom: 20px;
}

table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 10px;
}

table, th, td {
    border: 1px solid #ddd;
}

th, td {
    padding: 10px;
    text-align: left;
}

th {
    background-color: #333;
    color: #fff;
}

button {
    background-color: #333;
    color: #fff;
    padding: 8px 12px;
    border: none;
    cursor: pointer;
}

button:hover {
    background-color: #555;
}

input, textarea {
    margin-bottom: 10px;
    padding: 8px;
}

/* Adjustments for smaller screens */
@media screen and (max-width: 600px) {
    nav ul {
        text-align: center;
        display: block;
    }

    nav ul li {
        display: block;
        margin: 5px 0;
    }
}


/* CSS para centralizar e alinhar os campos verticalmente */
form {
    margin-bottom: 20px;
    text-align: center; /* Alinha o conteúdo do formulário ao centro */
}

label {
    display: flex;
    margin-bottom: 5px;
    padding-left: 475px;
}

input, textarea, select {
    width: 550px; /* Faz os campos ocuparem 100% da largura do contêiner pai */
    padding: 8px;
    box-sizing: border-box; /* Garante que o preenchimento não altere a largura total do elemento */
    margin-bottom: 10px;
}

button {
    margin-top: 10px; /* Adiciona um espaçamento superior ao botão */
}

/* Ajustes para telas menores */
@media screen and (max-width: 600px) {
    form {
        width: 80%; /* Reduz a largura do formulário para telas menores */
        margin: 0 auto; /* Centraliza o formulário na tela */
    }
}


    </style>
</head>
<body>

<h1>Bem Vindo(a), Administrador(a)!</h1>

<nav>
    <ul>
        <li><a target="_blank" href="category.php">Categoria</a></li>  
        <li><a target="_blank" href="books.php">Livros</a></li>
        <li><a target="_blank" href="contact.php">Contato</a></li>
        <li><a target="_blank" href="logout.php">Sair</a></li>
    </ul>
</nav>

<h2>Adicionar Novo Livro</h2>
<section>
<form action="admin_dashboard.php" method="post"><label><center><h1>Adicionar Livro</h1></center></label>
    <label for="title">Titulo</label>
    <input type="text" id="title" name="title" placeholder="Titulo do novo livro" required />
    <label for="description">Descrição</label>
    <textarea id="description" name="description" placeholder="Descrição do novo livro" required ></textarea>
    <label for="author">Autor</label>
    <input type="text" id="author" name="author" placeholder="Autor do novo livro" required />
    <!-- Lista suspensa (dropdown) para selecionar a categoria -->
    <label for="category">Categoria</label>
    <select id="category" name="id" required>
        
        <?php
        $categories = getCategories($conn);
        foreach ($categories as $category) {
            echo "<option value='{$category['id']}'>{$category['name']}</option>";
        }
        ?> 
    </select>
    <br /><button type="submit">Adicionar Livro</button>
</form>
    
</section>

<h2>Livros</h2>
<ul> 
    <?php
    $result = $conn->query("SELECT * FROM livros");
    while ($row = $result->fetch_assoc()) {
        echo "<li>{$row['title']} by {$row['author']}</li>";
    }
    ?> 
</ul>

</body>
</html> 

<!--
<
session_start();

// Conectar ao banco de dados (substitua com suas credenciais)
$conn = new mysqli("localhost", "root", "", "livraria_online");

// Verificar a conexão
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Verificar se o usuário está logado como administrador
if (!isset($_SESSION['admin']) || $_SESSION['admin'] !== true) {
    header("Location: login.php"); // Redireciona para a página de login se não estiver logado como administrador
    exit();
}

// Adicionar categoria ao banco de dados
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $title = $_POST['title'];
    $description = $_POST['description'];
    $author = $_POST['author'];
    $category_id = $_POST['category_idQ'];

    $sql = "INSERT INTO books (title, description, author, category_id) VALUES ('$title', '$description', '$author', '$category_id')";

    if ($conn->query($sql) === TRUE) {
        echo "Book added successfully!";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Função para obter todas as categorias
function getCategories($conn) {
    $categories = array();
    $result = $conn->query("SELECT * FROM categories");
    while ($row = $result->fetch_assoc()) {
        $categories[] = $row;
    }
    return $categories;
} 

// Adicionar livro ao banco de dados
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $title = $_POST['title'];
    $description = $_POST['description'];
    $author = $_POST['author'];
    $category = $_POST['category']; // Alteração aqui

    // Verificar se a categoria existe antes de inserir
    $checkCategory = $conn->query("SELECT category_id FROM categories WHERE category_name = '$category'");

    if ($checkCategory->num_rows > 0) {
        $row = $checkCategory->fetch_assoc();
        $category_id = $row['category_id'];

        $sql = "INSERT INTO books (title, description, author, category_id) VALUES ('$title', '$description', '$author', '$category_id')";

        if ($conn->query($sql) === TRUE) {
            echo "Book added successfully!";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    } else {
        echo "Category does not exist. Please add the category first.";
    }
}


?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
</head>
<body>

<h1>Welcome, Admin!</h1>

<nav>
    <ul>
        <li><a href="category.php">Category</a></li>
        <li><a href="subcategory.php">Sub-category</a></li>
        <li><a href="books.php">Books</a></li>
        <li><a href="contact.php">Contact</a></li>
        <li><a href="logout.php">Logout</a></li>
    </ul>
</nav>

<h2>Add New Book</h2>
<form action="admin_dashboard.php" method="post">
    <label for="title">Title:</label>
    <input type="text" id="title" name="title" required>

    <label for="description">Description:</label>
    <textarea id="description" name="description" required></textarea>

    <label for="author">Author:</label>
    <input type="text" id="author" name="author" required>

    <label for="category">Category:</label>
    <select id="category" name="category_id" required>
        /*
        <
        $categories = getCategories($conn);
        foreach ($categories as $category) {
            echo "<option value='{$category['category_id']}'>{$category['category_name']}</option>";
        }
        ?>
    </select>

    <button type="submit">Add Book</button>
</form>

<h2>Books</h2>
<ul>
    <
    $result = $conn->query("SELECT * FROM books");
    while ($row = $result->fetch_assoc()) {
        echo "<li>{$row['title']} by {$row['author']} (Category: {$row['category_id']})</li>";
    }
    ?>
</ul>

</body>
</html>
-->