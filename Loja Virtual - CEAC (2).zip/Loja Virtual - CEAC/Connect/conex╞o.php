<!-- Formulário de Conexão Completo Com PHP8, - author - By Éderson P.S - -->
<!DOCTYPE html>
<html lang="pt-BR">
    <meta charset="UTF-8">
    <meta name="author" content="Éderson P.S">
    <meta http-equiv="X-UA-Compatible" content="IE-edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <head>
    <title>
    Conexão!
    </title>
    </head>
    <!-- Conexão do Código com PHP -->
    <?php
$hostname = "localhost";
$username = "root";
$password = "";
$dbname = "livraria_online";

$conexao = new mysqli($hostname, $username, $password, $dbname);

/*
if($conexao->connect_errno){
    echo "Erro";
}else{
    echo "Conexão Efetuada com Sucesso!";
} */

/*if ($conn->connect_error) {
    die("Conexão falhou: "  . $conn->connect_error);
} */
?>

</body>
</html>