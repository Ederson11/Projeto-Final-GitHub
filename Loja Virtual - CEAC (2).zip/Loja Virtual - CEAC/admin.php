<?php
session_start();

// Verifica se o usuário está logado como administrador
if (!isset($_SESSION['admin']) || $_SESSION['admin'] !== true) {
    header("Location: login.php"); // Redireciona para a página de login se não estiver logado como administrador
    exit();
}

// Simula o carregamento de categorias, subcategorias e livros (substitua isso com dados do banco de dados)
$categories = ['Category 1', 'Category 2', 'Category 3'];
$subcategories = ['Subcategory 1', 'Subcategory 2', 'Subcategory 3'];
$books = ['Book 1', 'Book 2', 'Book 3'];

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
</head>
<body>

<h1>Welcome, Admin!</h1>

<nav>
    <ul>
        <li><a href="category.php">Category</a></li>
        <li><a href="subcategory.php">Sub-category</a></li>
        <li><a href="books.php">Books</a></li>
        <li><a href="contact.php">Contact</a></li>
        <li><a href="logout.php">Logout</a></li>
    </ul>
</nav>

<h2>Categories</h2>
<ul>
    <?php foreach ($categories as $category): ?>
        <li><?php echo $category; ?></li>
    <?php endforeach; ?>
</ul>

<h2>Subcategories</h2>
<ul>
    <?php foreach ($subcategories as $subcategory): ?>
        <li><?php echo $subcategory; ?></li>
    <?php endforeach; ?>
</ul>

<h2>Books</h2>
<ul>
    <?php foreach ($books as $book): ?>
        <li><?php echo $book; ?></li>
    <?php endforeach; ?>
</ul>

</body>
</html>
