<?php 
    session_start();
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Carrinho de Compras</title>
    <style type="text/css">
        *{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: sans-Serif;
        }
        h2.title{
            background-color: #069;
            width: 100%;
            padding: 20px;
            text-align: center;
            color: #f5f5f5;
        }
        .carrinho-container{
            display: flex;
            margin-top: 10px;
        }
        .produto{
            width: 33.3%;
            padding: 0 30px;
        }
        .produto img{
            max-width: 100%;
        }
        .produto a{
            display: block;
            width: 100%;
            padding: 10px;
            color: #f5f5f5;
            background-color: #5fb382;
            text-decoration: none;
            text-align: center;
        }
        .carrinho-item{
            max-width: 1200px;
            margin: 10px auto; 
            padding-bottom: 10px;
            border-bottom: 2px dotted #ccc;
        }
        .carrinho-item p{
            font-size: 19px;
            color: #ccc;
        }
    </style>
</head>
<body>
    <h2 class="title">Adicionar ao Carrinho</h2>
    <div class="carrinho-container">
<?php 
    $items = array(
    ['nome'=>'Pai Rico Pai Pobre','imagem'=>'img/livro-1.jpg','preco'=>'70'],
    ['nome'=>'Código Limpo','imagem'=>'img/livro-2.jpg','preco'=>'62'],
    ['nome'=>'Algoritimos','imagem'=>'img/livro-3.jpg','preco'=>'81'],
    ['nome'=>'Pense em Python','imagem'=>'img/livro-4.jpg','preco'=>'162']);
echo '<script>alert("No Momento só temos 2 livros á venda- Por Questão de Erros! ");</script>';
    foreach ($items as $key => $value) {
?>
<div class="produto">
        <img src="<?php echo $value['imagem'] ?>" />
        <a href="?adicionar=<?php echo $key ?>">Adicionar ao Carrinho!</a>
</div><!-- produto -->
<?php
    }
?>
    </div><!-- carrinho-container -->

    <?php 
        if(isset($_GET['adicionar'])){
            //Vamos adicionar ao carrinho.
            $idProduto = (int) $_GET['adicionar'];
            if(isset($items[$idProduto])){
                if(isset($_SESSION['carrinho'][$idProduto])){
                    $_SESSION['carrinho'][$idProduto]['quantidade']++;
                }else{
                    $_SESSION['carrinho'][$idProduto] = array('quantidade'=>1,'nome'=>$items[$idProduto]['nome'],'preco'=>$items[$idProduto]['preco']);
                }
                echo '<script>alert("O item foi adicionado ao carrinho.");</script>';
            }else{
                die('Você não pode adicionar um item que não existe.');
            }
        }
    ?>

    <h2 class="title">Carrinho</h2>
    <?php 
        foreach ($_SESSION['carrinho'] as $key => $value) {
            //Nome do Produto 
            //Quantidade 
            //Preço
            echo '<div class="carrinho-item">';
            echo '<p>Nome: '.$value['nome'].' | Quantidade: '.$value['quantidade'].' | Preço R$'.($value['quantidade']*$value['preco']).',00</p>';
            echo '</div>';
        }
    ?> 
</body>
</html>