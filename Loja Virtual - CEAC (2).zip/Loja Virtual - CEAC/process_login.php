<?php
session_start();

// Conectar ao banco de dados (substitua com suas credenciais)
$conn = new mysqli("localhost", "root", "", "livraria_online");

// Verificar a conexão
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Obter dados do formulário
$username = $_POST['username'];
$password = $_POST['password'];

// Consultar o banco de dados para verificar as credenciais
$sql = "SELECT * FROM administradores WHERE username = '$username'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    if (password_verify($password, $row['password'])) {
        // Login bem-sucedido, iniciar a sessão
        $_SESSION['admin'] = true;
        $_SESSION['username'] = $username;
        header("Location: admin_dashboard.php"); // Redirecionar para o painel de administração
        exit();
    } else {
        echo "Invalid password";
    }
} else {
    echo "Invalid username";
}

// Fechar a conexão
$conn->close();
?>
